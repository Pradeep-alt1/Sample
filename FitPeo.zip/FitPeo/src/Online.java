import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Online extends Base{

	
	public static void main(String[] args) throws InterruptedException {
		//Launch the browser
		WebDriver d =getDriver();
		//Launch the URL
		loadUrl("https://www.bestbuy.ca/en-ca/");
		//Maximize the window
		d.manage().window().maximize();
		//Providing implicit wait
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		//Type ipad in search bar
		WebElement search = d.findElement(By.xpath("//input[@name='search']"));
		type(search, "ipad");
		//Click the option from dropdown
		WebElement option = d.findElement(By.xpath("(//a[contains(text(),' pro')])[1]"));
		btnClick(option);
		Thread.sleep(10000);
		//Selecting online only filter
		WebElement filter = d.findElement(By.xpath("//span[text()='Online Only']"));
		btnClick(filter);
		//Selecting the first option
		WebElement firstOp = d.findElement(By.xpath("(//div[@itemprop='name'])[1]"));
		btnClick(firstOp);
		//scroll down to the add to cart button
		WebElement scroll = d.findElement(By.xpath("//span[text()='Available online only']"));
		WebElement addTo = d.findElement(By.xpath("(//form[@id='test'])[1]"));
		JavascriptExecutor js =(JavascriptExecutor)d;
		js.executeScript("arguments[0].scrollIntoView(true)", scroll);
		//js.executeScript("arguments[0].click",addTo);
		//click the add to cart button
		btnClick(addTo);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
